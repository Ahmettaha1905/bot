Python (https://www.python.org/downloads/) indirip kurun.

Node.js (https://nodejs.org/en/download) indirip kurun.

Dosya'nın herhangi boş bir yerine shift sağ tıklayıp powersehell'de açın. 

pip install yazın. Modüller kurulunca kapatabilirsiniz.

Main.py yi başlatın ve gerekli yerleri doldurun bu kadar.


