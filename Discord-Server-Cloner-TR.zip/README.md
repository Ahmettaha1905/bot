# Discord-Server-Cloner-TR
Discord sunucu kopyalama

**Gerekli kaynaklar;**
+ https://nodejs.org/en
+ https://www.python.org

**Kopyalayabildikleri**
+ Kanalları
+ Kanal ayarları
+ Sunucu rolleri
+ Sunucu ismini
+ Sunucu Banner / Resmini
+ Sunucu Emojilerini
+ Sunucu Ayarlarını

**Kopyalamadıkları**
- Sunucu Mesajları
- Sunucu Üyeleri
